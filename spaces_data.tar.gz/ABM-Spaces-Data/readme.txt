The data files in this directory contain the data used in the ABM-Spaces paper (doc_spaces.tex)

Each of the CSV files contain outputs of 10,000 simulations

Scenarios for the primary analysis
* a.csv = No CTI and TaT =2
* b.csv = CTI and TaT =2 (with testing of contacts)
* c.csv = CTI and TaT = 2 (with testing of contacts)
* d.csv = CTI and TaT = 2(without testing of contacts)
* e.csv = CTI and TaT = 2 (without testing of contacts)
(You can render HTML analysis of these five files using RMarkdown and the five.rmd file found in the repository)

Scenarios for the secondary analysis
* t2.csv up to t11.csv contain the outputs of simulations with CTI and TaT = 2 up to TaT =11 (all with testing of contacts)
* t2n.csv up to t11n.csv contain the outputs of simulations with CTI and TaT = 2 up to TaT =11 (all without testing of contacts)
(You can render HTML analysis of these 20 files using RMarkdown and the TaT2.rmd file found in the repository)  